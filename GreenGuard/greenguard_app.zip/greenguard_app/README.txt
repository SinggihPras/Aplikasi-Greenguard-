GREENGUARD - Deteksi Penyakit Daun Cabai
========================================

Deskripsi:
----------
Greenguard adalah aplikasi berbasis Streamlit yang digunakan untuk mendeteksi penyakit pada daun tanaman cabai dari gambar yang diunggah. Aplikasi ini memberikan prediksi jenis penyakit serta rekomendasi tindakan yang dapat dilakukan.

Fitur:
------
- Mengunggah gambar daun cabai (format JPG, JPEG, PNG)
- Klasifikasi dummy ke dalam 4 kategori:
  1. Daun Sehat
  2. Bercak Daun
  3. Keriting
  4. Busuk Daun
- Tampilan antarmuka interaktif menggunakan Streamlit
- Rekomendasi tindakan berdasarkan hasil prediksi

Persyaratan:
------------
- Python 3.7+
- Streamlit
- Pillow
- NumPy

Instalasi:
----------
1. Install dependensi:
   pip install streamlit pillow numpy

2. Jalankan aplikasi:
   streamlit run greenguard.py

   *Jika perintah di atas tidak dikenali, gunakan:*
   python -m streamlit run greenguard.py

Catatan:
--------
- Saat ini, prediksi dilakukan secara acak (dummy) dan belum menggunakan model machine learning yang sesungguhnya.
- Aplikasi ini bisa dikembangkan lebih lanjut dengan menambahkan model deteksi berbasis deep learning.

Lisensi:
--------
Aplikasi ini bersifat open-source untuk keperluan edukasi dan penelitian.

